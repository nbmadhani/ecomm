

<?php $__env->startSection('Title', 'Category'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><?php echo $__env->yieldContent('Title'); ?></h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('admin.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-8">
                <label for="category_id">Search by category</label>
                <form method="GET" action="" class="form-inline">
                    <div class="form-row">
                        <div class="col-7 mb-3">
                            <select name="category_id" id="category_id"
                                class="form-control<?php echo e($errors->has('category_id') ? ' is-invalid' : ''); ?>" required>
                                <option value=""><?php echo e(__('-- Select Category --')); ?></option>
                                <?php $__empty_1 = true; $__currentLoopData = $RS_Results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $RS_Row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($RS_Row->id); ?>"
                                        <?php echo e(Request::input('category_id') == $RS_Row->id ? 'selected' : ''); ?>>
                                        <?php echo e($RS_Row->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </select>

                            <?php if($errors->has('category_id')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('category_id')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="col-3">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp_8\htdocs\ecomm-jwt\resources\views/categories/index.blade.php ENDPATH**/ ?>