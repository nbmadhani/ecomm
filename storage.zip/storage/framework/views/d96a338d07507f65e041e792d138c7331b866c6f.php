

<?php $__env->startSection('Title', 'Category List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><?php echo $__env->yieldContent('Title'); ?></h2>
            </div>
            <div class="col-md-4 text-right">
                <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-info">Add Category</a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('admin.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <?php if($RS_Results->count() > 0): ?>
                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">Name</th>
                                <th scope="col" width="20%">
                                    <center>Action</center>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $RS_Results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $RS_Row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="delete-<?php echo e($RS_Row->id); ?>">
                                    <td><?php echo e($RS_Row->name); ?></td>
                                    <td>
                                        <center>
                                            <a href="<?php echo e(route('admin.categories.edit', $RS_Row->id)); ?>" title="Edit"
                                                class="btn btn-sm btn-primary mx-2">Edit</a>

                                            <a href="javascript:;" title="Delete" data-toggle="modal"
                                                data-target="#ajaxModelDelete" data-title="Category"
                                                data-id="<?php echo e($RS_Row->id); ?>"
                                                data-url="<?php echo e(route('admin.categories.destroy', $RS_Row->id)); ?>"
                                                class="btn btn-sm btn-danger delete">Delete</a>
                                        </center>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <?php echo $RS_Results->onEachSide(1)->links('pagination::bootstrap-5'); ?>

                <?php else: ?>
                    <h4><?php echo e(__('Record not found')); ?></h4>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp_8\htdocs\ecomm-jwt\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>