

<?php $__env->startSection('Title', 'Order List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><?php echo $__env->yieldContent('Title'); ?></h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('admin.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <?php if($RS_Results->count() > 0): ?>
                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col" width="10%">Order ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Total</th>
                                <th scope="col" width="20%">
                                    <center>Action</center>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $RS_Results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $RS_Row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="delete-<?php echo e($RS_Row->id); ?>">
                                    <td><?php echo e($RS_Row->id); ?></td>
                                    <td><?php echo e($RS_Row->name); ?></td>
                                    <td><?php echo e($RS_Row->email); ?></td>
                                    <td><?php echo e($RS_Row->total); ?></td>
                                    <td></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <?php echo $RS_Results->onEachSide(1)->links('pagination::bootstrap-5'); ?>

                <?php else: ?>
                    <h4><?php echo e(__('Record not found')); ?></h4>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp_8\htdocs\ecomm-jwt\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>