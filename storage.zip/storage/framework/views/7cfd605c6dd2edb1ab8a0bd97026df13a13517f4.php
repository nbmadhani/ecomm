

<?php $__env->startSection('Title', (!empty($RS_Row) ? 'Edit' : 'Add') . ' Category'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><?php echo $__env->yieldContent('Title'); ?></h2>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(!empty($RS_Row)): ?>
                    <?php $action = route('admin.categories.update', $RS_Row->id); ?>
                <?php else: ?>
                    <?php $action = route('admin.categories.store'); ?>
                <?php endif; ?>

                <form method="POST" action="<?php echo e($action); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if(!empty($RS_Row)): ?>
                        <?php echo e(method_field('PUT')); ?>

                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" name="name" id="name" value="<?php echo e(old('name', $RS_Row->name ?? '')); ?>"
                            class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>">

                        <?php if($errors->has('name')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="slug" class="form-label">Slug</label>
                        <input type="text" name="slug" id="slug" value="<?php echo e(old('slug', $RS_Row->slug ?? '')); ?>"
                            class="form-control<?php echo e($errors->has('slug') ? ' is-invalid' : ''); ?>">

                        <?php if($errors->has('slug')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('slug')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            $("#name").on('blur', function(e) {
                e.preventDefault();

                let name = slug($(this).val());
                $('#slug').val(name);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp_8\htdocs\ecomm-jwt\resources\views/admin/categories/create-edit.blade.php ENDPATH**/ ?>