

<?php $__env->startSection('Title', 'Checkout'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><?php echo $__env->yieldContent('Title'); ?></h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('admin.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-6">
                <?php if(session('cart')): ?>
                    <form method="POST" action="<?php echo e(route('place.order')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" name="name" id="name" value="<?php echo e(Auth::user()->name); ?>"
                                class="form-control" readonly>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="text" name="email" id="email" value="<?php echo e(Auth::user()->email); ?>"
                                class="form-control" readonly>
                        </div>

                        <div class="mb-3">
                            <?php $total = 0 ?>
                            <?php $__currentLoopData = (array) session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $total += $details['price'] * $details['quantity'] ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <label for="total" class="form-label">Total</label>
                            <input type="text" name="total" id="total" value="$ <?php echo e($total); ?>"
                                class="form-control" readonly>
                        </div>

                        <button type="submit" class="btn btn-primary">Place Order</button>
                    </form>
                <?php else: ?>
                    <h3><?php echo e(__('Cart is empty')); ?></h3>
                    <a href="<?php echo e(route('front.products.index')); ?>" class="btn btn-warning">Continue Shopping</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp_8\htdocs\ecomm-jwt\resources\views/checkout.blade.php ENDPATH**/ ?>