

<?php $__env->startSection('Title', (!empty($RS_Row) ? 'Edit' : 'Add') . ' Category'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><?php echo $__env->yieldContent('Title'); ?></h2>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(!empty($RS_Row)): ?>
                    <?php $action = route('admin.products.update', $RS_Row->id); ?>
                <?php else: ?>
                    <?php $action = route('admin.products.store'); ?>
                <?php endif; ?>

                <form method="POST" action="<?php echo e($action); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(!empty($RS_Row)): ?>
                        <?php echo e(method_field('PUT')); ?>

                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" name="name" id="name" value="<?php echo e(old('name', $RS_Row->name ?? '')); ?>"
                            class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>">

                        <?php if($errors->has('name')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="slug" class="form-label">Slug</label>
                        <input type="text" name="slug" id="slug" value="<?php echo e(old('slug', $RS_Row->slug ?? '')); ?>"
                            class="form-control<?php echo e($errors->has('slug') ? ' is-invalid' : ''); ?>">

                        <?php if($errors->has('slug')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('slug')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="category_id">Category</label>
                        <select name="category_id" id="category_id"
                            class="form-control<?php echo e($errors->has('category_id') ? ' is-invalid' : ''); ?>">
                            <option value=""><?php echo e(__('-- Select Category --')); ?></option>
                            <?php $__empty_1 = true; $__currentLoopData = $RS_Result_Cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $RS_Row_Cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($RS_Row_Cat->id); ?>"
                                    <?php echo e(old('category_id', $RS_Row->category_id ?? '') == $RS_Row_Cat->id ? 'selected' : ''); ?>>
                                    <?php echo e($RS_Row_Cat->name); ?>

                                    <?php echo e(!empty($RS_Row_Cat->category_id) ? ', ' . $RS_Row_Cat->parents->pluck('name')->implode(', ') : ''); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </select>

                        <?php if($errors->has('category_id')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('category_id')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="price" class="form-label">Price</label>
                        <input type="text" name="price" id="price"
                            value="<?php echo e(old('price', $RS_Row->price ?? '')); ?>"
                            class="form-control<?php echo e($errors->has('price') ? ' is-invalid' : ''); ?>">

                        <?php if($errors->has('price')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('price')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea name="description" id="description"
                            class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>"><?php echo e(old('description', $RS_Row->description ?? '')); ?></textarea>

                        <?php if($errors->has('description')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('description')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="image" class="form-label">Image</label>
                        <input type="file" name="image" id="image"
                            value="<?php echo e(old('image', $RS_Row->image ?? '')); ?>"
                            class="form-control<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>" accept="image/*">

                        <?php if($errors->has('image')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('image')); ?></strong>
                            </span>
                        <?php endif; ?>

                        <?php if(!empty($RS_Row->image)): ?>
                            <img src="<?php echo e($RS_Row->image); ?>" class="img-fluid img-thumbnail mt-3">
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function() {
            $("#name").on('blur', function(e) {
                e.preventDefault();

                let name = slug($(this).val());
                $('#slug').val(name);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp_8\htdocs\ecomm-jwt\resources\views/admin/products/create-edit.blade.php ENDPATH**/ ?>