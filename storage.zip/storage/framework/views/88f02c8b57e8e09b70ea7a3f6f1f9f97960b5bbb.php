<?php if(Session::has('messageType')): ?>
    <div class="row">
        <div class="col-md-12">
            <div
                class="alert alert-dismissible <?php if(Session::get('messageType') == 'success'): ?> alert-success <?php elseif(Session::get('messageType') == 'info'): ?> alert-info <?php else: ?> alert-danger <?php endif; ?>">
                <?php echo Session::get('message'); ?>

            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH F:\xampp_8\htdocs\ecomm-jwt\resources\views/admin/layouts/messages.blade.php ENDPATH**/ ?>