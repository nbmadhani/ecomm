

<?php $__env->startSection('Title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2><?php echo $__env->yieldContent('Title'); ?></h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('admin.layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <div class="row justify-content-center mb-4">
            <div class="col-md-8">
                <label for="category_id">Search by category</label>
                <form method="GET" action="" class="form-inline">
                    <div class="form-row">
                        <div class="col-7 mb-3">
                            <select name="category_id" id="category_id"
                                class="form-control<?php echo e($errors->has('category_id') ? ' is-invalid' : ''); ?>">
                                <option value=""><?php echo e(__('-- Select Category --')); ?></option>
                                <?php $__empty_1 = true; $__currentLoopData = $RS_Result_Cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $RS_Row_Cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($RS_Row_Cat->id); ?>"
                                        <?php echo e(Request::input('category_id') == $RS_Row_Cat->id ? 'selected' : ''); ?>>
                                        <?php echo e($RS_Row_Cat->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </select>

                            <?php if($errors->has('category_id')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('category_id')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="col-3">
                            <button type="submit" class="btn btn-dark">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $RS_Results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $RS_Row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-3 mb-4">
                    <div class="border">
                        <img src="<?php echo e($RS_Row->image); ?>" class="card-img-top" alt="<?php echo e($RS_Row->name); ?>">
                        <div class="card-body p-3">
                            <h5 class="card-title"><?php echo e($RS_Row->name); ?></h5>
                            <p class="card-text">Price: <?php echo e($RS_Row->price); ?></p>
                            <a href="<?php echo e(route('add.to.cart', $RS_Row->id)); ?>" class="btn btn-primary" role="button">Add to
                                cart</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp_8\htdocs\ecomm-jwt\resources\views/products/index.blade.php ENDPATH**/ ?>