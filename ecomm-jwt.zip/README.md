# First copy to project in github
# Composer update command run
# cp .env.example .env
# php artisan key:generate
# if required run this command
	- php artisan vendor:publish --provider="PHPOpenSourceSaver\JWTAuth\Providers\LaravelServiceProvider"
# php artisan jwt:secret
# npm run dev
# migrate database
# php artisan serve run command

Admin User: admin@admin.com
Admin Pass: Password@123"# ecomm" 
"# ecomm" 
