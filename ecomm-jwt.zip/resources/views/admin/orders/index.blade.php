@extends('admin.layouts.app')

@section('Title', 'Order List')

@section('content')
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2>@yield('Title')</h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                @include('admin.layouts.messages')
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                @if ($RS_Results->count() > 0)
                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col" width="10%">Order ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Total</th>
                                <th scope="col" width="20%">
                                    <center>Action</center>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($RS_Results as $RS_Row)
                                <tr class="delete-{{ $RS_Row->id }}">
                                    <td>{{ $RS_Row->id }}</td>
                                    <td>{{ $RS_Row->name }}</td>
                                    <td>{{ $RS_Row->email }}</td>
                                    <td>{{ $RS_Row->total }}</td>
                                    <td>
                                        <a href="#">View</a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    {!! $RS_Results->onEachSide(1)->links('pagination::bootstrap-5') !!}
                @else
                    <h4>{{ __('Record not found') }}</h4>
                @endif
            </div>
        </div>
    </div>
@endsection
