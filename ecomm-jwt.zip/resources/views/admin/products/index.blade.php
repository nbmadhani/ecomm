@extends('admin.layouts.app')

@section('Title', 'Product List')

@section('content')
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2>@yield('Title')</h2>
            </div>
            <div class="col-md-4 text-right">
                <a href="{{ route('admin.products.create') }}" class="btn btn-info">Add Product</a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                @include('admin.layouts.messages')
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                @if ($RS_Results->count() > 0)
                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">Name</th>
                                <th scope="col" width="5%">Price</th>
                                <th scope="col" width="10%">Category</th>
                                <th scope="col" width="15%">
                                    <center>Action</center>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($RS_Results as $RS_Row)
                                <tr class="delete-{{ $RS_Row->id }}">
                                    <td>{{ $RS_Row->name }}</td>
                                    <td>{{ $RS_Row->price }}</td>
                                    <td>{{ $RS_Row->category->name }}</td>
                                    <td>
                                        <center>
                                            <a href="{{ route('admin.products.edit', $RS_Row->id) }}" title="Edit"
                                                class="btn btn-sm btn-primary mx-2">Edit</a>

                                            <a href="javascript:;" title="Delete" data-toggle="modal"
                                                data-target="#ajaxModelDelete" data-title="Product"
                                                data-id="{{ $RS_Row->id }}"
                                                data-url="{{ route('admin.products.destroy', $RS_Row->id) }}"
                                                class="btn btn-sm btn-danger delete">Delete</a>
                                        </center>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    {!! $RS_Results->onEachSide(1)->links('pagination::bootstrap-5') !!}
                @else
                    <h4>{{ __('Record not found') }}</h4>
                @endif
            </div>
        </div>
    </div>
@endsection
