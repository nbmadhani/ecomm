@extends('admin.layouts.app')

@section('Title', (!empty($RS_Row) ? 'Edit' : 'Add') . ' Category')

@section('content')
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2>@yield('Title')</h2>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                @if (!empty($RS_Row))
                    @php $action = route('admin.products.update', $RS_Row->id); @endphp
                @else
                    @php $action = route('admin.products.store'); @endphp
                @endif

                <form method="POST" action="{{ $action }}" enctype="multipart/form-data">
                    @csrf
                    @if (!empty($RS_Row))
                        {{ method_field('PUT') }}
                    @endif

                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" name="name" id="name" value="{{ old('name', $RS_Row->name ?? '') }}"
                            class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}">

                        @if ($errors->has('name'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('name') }}</strong>
                            </span>
                        @endif
                    </div>

                    <div class="mb-3">
                        <label for="slug" class="form-label">Slug</label>
                        <input type="text" name="slug" id="slug" value="{{ old('slug', $RS_Row->slug ?? '') }}"
                            class="form-control{{ $errors->has('slug') ? ' is-invalid' : '' }}">

                        @if ($errors->has('slug'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('slug') }}</strong>
                            </span>
                        @endif
                    </div>

                    <div class="mb-3">
                        <label for="category_id">Category</label>
                        <select name="category_id" id="category_id"
                            class="form-control{{ $errors->has('category_id') ? ' is-invalid' : '' }}">
                            <option value="">{{ __('-- Select Category --') }}</option>
                            @forelse($RS_Result_Cats as $RS_Row_Cat)
                                <option value="{{ $RS_Row_Cat->id }}"
                                    {{ old('category_id', $RS_Row->category_id ?? '') == $RS_Row_Cat->id ? 'selected' : '' }}>
                                    {{ $RS_Row_Cat->name }}
                                    {{ !empty($RS_Row_Cat->category_id) ? ', ' . $RS_Row_Cat->parents->pluck('name')->implode(', ') : '' }}
                                </option>
                            @empty
                            @endforelse
                        </select>

                        @if ($errors->has('category_id'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('category_id') }}</strong>
                            </span>
                        @endif
                    </div>

                    <div class="mb-3">
                        <label for="price" class="form-label">Price</label>
                        <input type="text" name="price" id="price"
                            value="{{ old('price', $RS_Row->price ?? '') }}"
                            class="form-control{{ $errors->has('price') ? ' is-invalid' : '' }}">

                        @if ($errors->has('price'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('price') }}</strong>
                            </span>
                        @endif
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea name="description" id="description"
                            class="form-control{{ $errors->has('description') ? ' is-invalid' : '' }}">{{ old('description', $RS_Row->description ?? '') }}</textarea>

                        @if ($errors->has('description'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('description') }}</strong>
                            </span>
                        @endif
                    </div>

                    <div class="mb-3">
                        <label for="image" class="form-label">Image</label>
                        <input type="file" name="image" id="image"
                            value="{{ old('image', $RS_Row->image ?? '') }}"
                            class="form-control{{ $errors->has('image') ? ' is-invalid' : '' }}" accept="image/*">

                        @if ($errors->has('image'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('image') }}</strong>
                            </span>
                        @endif

                        @if (!empty($RS_Row->image))
                            <img src="{{ $RS_Row->image }}" class="img-fluid img-thumbnail mt-3">
                        @endif
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        $(function() {
            $("#name").on('blur', function(e) {
                e.preventDefault();

                let name = slug($(this).val());
                $('#slug').val(name);
            });
        });
    </script>
@endsection
