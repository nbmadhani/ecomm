@extends('admin.layouts.app')

@section('Title', (!empty($RS_Row) ? 'Edit' : 'Add') . ' Category')

@section('content')
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2>@yield('Title')</h2>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                @if (!empty($RS_Row))
                    @php $action = route('admin.categories.update', $RS_Row->id); @endphp
                @else
                    @php $action = route('admin.categories.store'); @endphp
                @endif

                <form method="POST" action="{{ $action }}">
                    @csrf
                    @if (!empty($RS_Row))
                        {{ method_field('PUT') }}
                    @endif

                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" name="name" id="name" value="{{ old('name', $RS_Row->name ?? '') }}"
                            class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}">

                        @if ($errors->has('name'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('name') }}</strong>
                            </span>
                        @endif
                    </div>

                    <div class="mb-3">
                        <label for="slug" class="form-label">Slug</label>
                        <input type="text" name="slug" id="slug" value="{{ old('slug', $RS_Row->slug ?? '') }}"
                            class="form-control{{ $errors->has('slug') ? ' is-invalid' : '' }}">

                        @if ($errors->has('slug'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('slug') }}</strong>
                            </span>
                        @endif
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        $(function() {
            $("#name").on('blur', function(e) {
                e.preventDefault();

                let name = slug($(this).val());
                $('#slug').val(name);
            });
        });
    </script>
@endsection
