@extends('layouts.app')

@section('Title', 'Order Place')

@section('content')
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2>@yield('Title')</h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                @include('admin.layouts.messages')
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-6">
                <h3>Order Place</h3>
                <h3>Order ID: {{ Request::input('id') }}</h3>
            </div>
        </div>
    </div>
@endsection
