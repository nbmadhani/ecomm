@extends('layouts.app')

@section('Title', 'Checkout')

@section('content')
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2>@yield('Title')</h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                @include('admin.layouts.messages')
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-6">
                @if (session('cart'))
                    <form method="POST" action="{{ route('place.order') }}">
                        @csrf

                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" name="name" id="name" value="{{ Auth::user()->name }}"
                                class="form-control" readonly>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="text" name="email" id="email" value="{{ Auth::user()->email }}"
                                class="form-control" readonly>
                        </div>

                        <div class="mb-3">
                            @php $total = 0 @endphp
                            @foreach ((array) session('cart') as $id => $details)
                                @php $total += $details['price'] * $details['quantity'] @endphp
                            @endforeach

                            <label for="total" class="form-label">Total</label>
                            <input type="text" name="total" id="total" value="$ {{ $total }}"
                                class="form-control" readonly>
                        </div>

                        <button type="submit" class="btn btn-primary">Place Order</button>
                    </form>
                @else
                    <h3>{{ __('Cart is empty') }}</h3>
                    <a href="{{ route('front.products.index') }}" class="btn btn-warning">Continue Shopping</a>
                @endif
            </div>
        </div>
    </div>
@endsection
