@extends('layouts.app')

@section('Title', 'Products')

@section('content')
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-8">
                <h2>@yield('Title')</h2>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                @include('admin.layouts.messages')
            </div>
        </div>

        <div class="row justify-content-center mb-4">
            <div class="col-md-8">
                <label for="category_id">Search by category</label>
                <form method="GET" action="" class="form-inline">
                    <div class="form-row">
                        <div class="col-7 mb-3">
                            <select name="category_id" id="category_id"
                                class="form-control{{ $errors->has('category_id') ? ' is-invalid' : '' }}">
                                <option value="">{{ __('-- Select Category --') }}</option>
                                @forelse($RS_Result_Cats as $RS_Row_Cat)
                                    <option value="{{ $RS_Row_Cat->id }}"
                                        {{ Request::input('category_id') == $RS_Row_Cat->id ? 'selected' : '' }}>
                                        {{ $RS_Row_Cat->name }}
                                    </option>
                                @empty
                                @endforelse
                            </select>

                            @if ($errors->has('category_id'))
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $errors->first('category_id') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="col-3">
                            <button type="submit" class="btn btn-dark">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="row">
            @forelse($RS_Results as $RS_Row)
                <div class="col-md-3 mb-4">
                    <div class="border">
                        <img src="{{ $RS_Row->image }}" class="card-img-top" alt="{{ $RS_Row->name }}">
                        <div class="card-body p-3">
                            <h5 class="card-title">{{ $RS_Row->name }}</h5>
                            <p class="card-text">Price: {{ $RS_Row->price }}</p>
                            <a href="{{ route('add.to.cart', $RS_Row->id) }}" class="btn btn-primary" role="button">Add to
                                cart</a>
                        </div>
                    </div>
                </div>
            @empty
            @endforelse
        </div>
    </div>
@endsection
