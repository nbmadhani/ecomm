<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Role;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $RS_Row = Role::select('id')->where('slug', 'admin')->first();

        // admin
        User::create([
            'role_id' => $RS_Row->id,
            'name' => 'Admin',
            'email' => 'admin@admin.com',
            'password' => Hash::make('Password@123'),
            'email_verified_at' => now(),
        ]);
    }
}
