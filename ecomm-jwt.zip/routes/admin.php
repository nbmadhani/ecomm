<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\OrderController;

Route::group(['prefix' => 'administrator', 'as' => 'admin.'], function () {

    // login user access route
    Route::group(['middleware' => ['auth', 'role.admin']], function () {
        Route::get('/', function () {
            return redirect()->route('admin.dashboard');
        });
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

        Route::resources(['categories' => CategoryController::class]);
        Route::resources(['products' => ProductController::class]);
        Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
    });
});
