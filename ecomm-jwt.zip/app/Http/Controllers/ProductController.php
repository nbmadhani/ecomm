<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repositories\Interfaces\CategoryRepositoryInterface;
use App\Repositories\Interfaces\ProductRepositoryInterface;

class ProductController extends Controller
{
    private $categoryRepository, $productRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(CategoryRepositoryInterface $categoryRepository, ProductRepositoryInterface $productRepository)
    {
        $this->categoryRepository = $categoryRepository;
        $this->productRepository = $productRepository;
    }

    public function index(Request $request)
    {
        $RS_Result_Cats = $this->categoryRepository->all();
        if (!empty($request->all())) {
            $RS_Results = $this->productRepository->searchProducts($request);
        } else {
            $RS_Results = $this->productRepository->all();
        }

        return view('products.index', compact('RS_Result_Cats', 'RS_Results'));
    }
}
