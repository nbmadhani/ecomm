<?php

namespace App\Http\Controllers;

use App\Repositories\Interfaces\OrderRepositoryInterface;
use Illuminate\Http\Request;

class CheckoutController extends Controller
{
    private $orderRepository;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(OrderRepositoryInterface $orderRepository)
    {
        $this->orderRepository = $orderRepository;
    }


    public function index()
    {
        return view('checkout');
    }

    public function placeOrder(Request $request)
    {
        $response = $this->orderRepository->placeOrder($request);

        session()->flash('messageType', $response['messageType']);
        session()->flash('message', $response['message']);

        return redirect()->route('order.place', 'id=' . $response['data']['id']);
    }

    public function orderPlace(Request $request)
    {
        return view('order-place');
    }
}
