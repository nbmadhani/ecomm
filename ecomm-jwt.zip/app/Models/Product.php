<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\MediaTrait;

class Product extends Model
{
    use HasFactory, MediaTrait;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'category_id',
        'name',
        'slug',
        'price',
        'description',
        'image',
    ];

    public function getImageAttribute($value)
    {
        return !empty($value) ? $this->mediaUrl($value) : NULL;
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }
}
