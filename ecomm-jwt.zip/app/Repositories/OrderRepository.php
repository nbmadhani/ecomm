<?php

namespace App\Repositories;

use App\Models\Order;
use App\Models\OrderItem;
use App\Repositories\Interfaces\OrderRepositoryInterface;

class OrderRepository implements OrderRepositoryInterface
{
    private $_title = 'Order';

    public function all()
    {
        return Order::paginate();
    }

    public function placeOrder($data)
    {
        $RS_Row = new Order();

        $RS_Row->user_id = auth()->user()->id;
        $RS_Row->name = $data->name;
        $RS_Row->email = $data->email;
        $RS_Row->total = 0;

        $RS_Row->save();

        if (!empty($RS_Row)) {
            if (!empty(session('cart'))) {
                $total = 0;
                foreach (session('cart') as $id => $details) {
                    $total += $details['price'] * $details['quantity'];

                    $RS_Row_Item = new OrderItem();

                    $RS_Row_Item->order_id = $RS_Row->id;
                    $RS_Row_Item->product_id = $id;
                    $RS_Row_Item->name = $details['name'];
                    $RS_Row_Item->quantity = $details['quantity'];
                    $RS_Row_Item->price = $details['price'];
                    $RS_Row_Item->sub_total = ($details['price'] * $details['quantity']);
                    $RS_Row_Item->image = $details['image'];
                    $RS_Row_Item->category = $details['category'];

                    $RS_Row_Item->save();
                }

                $RS_Row->update(['total' => $total]);
            }

            session()->put('cart', []);

            return array(
                'messageType' => 'success',
                'message' => "{$this->_title} place successfully.",
                'data' => $RS_Row
            );
        } else {
            return array(
                'messageType' => 'error',
                'message' => "Can\'t place order, try after sometime.",
                'data' => NULL
            );
        }
    }
}
